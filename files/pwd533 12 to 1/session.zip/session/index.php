<?php 
   session_start();

echo "<h1>Session start </h1>";

$_SESSION["name"]="Ali Raza Shahzad";
$_SESSION["fname"]="Raza";
$_SESSION["email"]="aliraza@gmail.com";
?>